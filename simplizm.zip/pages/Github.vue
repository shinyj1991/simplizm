<template>
  <article id="github">
    <page-title>Github</page-title>
  </article>
</template>

<script>
  export default {
    methods: {}
  }
</script>

<style lang="scss">
#github {padding: 50px;}

@media screen and (max-width: 750px) {
  
}
</style>