<template>
  <article id="story">
    <page-title>Story</page-title>
  </article>
</template>

<script>
  export default {
    methods: {}
  }
</script>

<style lang="scss">
#story {padding: 50px;}

@media screen and (max-width: 750px) {
  
}
</style>